# Ultra FPS Assistant — Android/Kotlin

Aplikasi pendamping aman untuk memeriksa refresh rate layar dan status daya/termal, serta memberi panduan optimasi Mobile Legends: Bang Bang.

## Batasan
- Tidak mengubah file atau konfigurasi internal MLBB.
- Tidak memakai root, injeksi, modifikasi APK game, atau bypass pembatasan.
- Tidak mengklaim dapat membuka 120 FPS.
- Refresh rate layar bukan pengukuran FPS aktual game.
- Pembacaan status termal bergantung pada versi Android dan dukungan perangkat.

## Cara membangun
1. Instal Android Studio versi stabil yang mendukung Android Gradle Plugin 8.7.x.
2. Ekstrak ZIP ini dan buka folder `UltraFPSAssistant` di Android Studio.
3. Tunggu Gradle Sync. Instal Android SDK Platform 35 dan JDK 17 bila diminta.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Interpretasi hasil
- 120 Hz berarti layar dapat menyegarkan hingga sekitar 120 kali per detik dalam mode tersebut.
- Ini tidak berarti game merender 120 frame per detik.
- Opsi FPS game ditentukan oleh dukungan resmi MLBB dan perangkat.
- ID paket MLBB dapat berbeda berdasarkan distribusi/region. Jika tombol buka game tidak menemukan game, buka MLBB secara manual.
