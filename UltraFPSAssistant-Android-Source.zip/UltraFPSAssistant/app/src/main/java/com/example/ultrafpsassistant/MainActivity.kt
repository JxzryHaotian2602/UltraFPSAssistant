package com.example.ultrafpsassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(0xFF10151D.toInt())
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("ULTRA FPS ASSISTANT", 25f, 0xFF70E1C1.toInt(), true)
        addText("MLBB • Android safe optimization", 14f, 0xFFB8C2D1.toInt())
        addText(
            "Aplikasi pendamping ini memeriksa kemampuan layar dan status daya. " +
                "Aplikasi tidak membuka batas FPS game, mengubah file MLBB, atau menjamin 120 FPS.",
            15f, 0xFFE5EAF0.toInt()
        )

        statusText = addText("", 15f, 0xFFFFFFFF.toInt())
        addButton("Periksa perangkat lagi") { updateStatus() }
        addButton("Buka pengaturan layar") {
            try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            catch (_: Exception) { showMessage("Pengaturan layar tidak tersedia pada perangkat ini.") }
        }
        addButton("Buka pengaturan baterai") {
            try { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        addButton("Buka Mobile Legends") { openMlbb() }

        addText("PANDUAN AMAN", 19f, 0xFF70E1C1.toInt(), true)
        addText("• Pilih refresh rate tertinggi yang tersedia di pengaturan layar.", 15f, 0xFFE5EAF0.toInt())
        addText("• Di MLBB, pilih opsi frame rate tertinggi yang memang tersedia.", 15f, 0xFFE5EAF0.toInt())
        addText("• Untuk mengurangi panas, hindari bermain sambil mengisi daya dan turunkan kualitas grafis jika perlu.", 15f, 0xFFE5EAF0.toInt())
        addText("• Menutup aplikasi latar belakang yang tidak diperlukan dapat membantu, tetapi tidak menjamin FPS naik.", 15f, 0xFFE5EAF0.toInt())
        addText("CATATAN", 19f, 0xFFFFD27D.toInt(), true)
        addText("Refresh rate layar bukan FPS aktual game. Kompatibilitas 120 FPS ditentukan juga oleh dukungan MLBB, chipset/GPU, suhu, dan versi game.", 14f, 0xFFB8C2D1.toInt())
        updateStatus()
    }

    @Suppress("DEPRECATION")
    private fun updateStatus() {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display
                     else windowManager.defaultDisplay
        val currentHz = display?.refreshRate ?: 0f
        val supportedHz = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                windowManager.defaultDisplay.supportedModes
                    .map { it.refreshRate }.distinct().sorted()
                    .joinToString(", ") { String.format(Locale.US, "%.0f Hz", it) }
            } else "Tidak dapat dibaca oleh versi Android ini"
        } catch (_: Exception) { "Tidak tersedia" }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val saver = pm.isPowerSaveMode
        val thermal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Sedikit meningkat"
                PowerManager.THERMAL_STATUS_MODERATE -> "Sedang"
                PowerManager.THERMAL_STATUS_SEVERE -> "Tinggi"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Kritis"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Darurat"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Sistem menuju mati otomatis"
                else -> "Tidak diketahui"
            }
        } else "Tidak didukung API Android perangkat"

        statusText.text = buildString {
            appendLine("STATUS PERANGKAT")
            appendLine("• Model: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("• Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("• Refresh rate saat ini: ${String.format(Locale.US, "%.0f Hz", currentHz)}")
            appendLine("• Mode layar yang dilaporkan: $supportedHz")
            appendLine("• Penghemat baterai: ${if (saver) "Aktif" else "Tidak aktif"}")
            appendLine("• Status termal sistem: $thermal")
            appendLine()
            appendLine("TARGET 120 FPS")
            if (currentHz >= 119f) {
                append("Layar melaporkan sekitar 120 Hz atau lebih. Ini TIDAK membuktikan MLBB mendukung 120 FPS.")
            } else {
                append("Layar saat ini tidak melaporkan 120 Hz. Periksa pengaturan layar untuk pilihan yang tersedia.")
            }
        }
    }

    private fun openMlbb() {
        val launch = packageManager.getLaunchIntentForPackage("com.mobile.legends")
        if (launch != null) startActivity(launch)
        else showMessage("Mobile Legends tidak ditemukan. Pastikan game terpasang dari sumber resmi.")
    }

    private fun addText(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val view = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(view, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        return view
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, dp(6), 0, dp(6))
        content.addView(button, params)
    }

    private fun showMessage(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
